//Jinhao Liu
#ifndef SEM_H
#define SEM_H
#include "threads.h"

typedef struct Semaphore
{
	int val;
	TCB_t *semQ;
} Semaphore;

void initSem(Semaphore *semaphore, int value)
{
	semaphore->semQ = NULL;
	semaphore->val = value;
}

void P(Semaphore *semaphore)
{
	if (semaphore->val > 0)
	{
		semaphore->val--;
	}
	else
	{
		if (head != NULL)
		{
			TCB_t *tcb = DelQueue(&head);
			AddQueue(&(semaphore->semQ), tcb);
			swapcontext(&(tcb->context), &(head->context));
		}
		else
		{
			exit(0);
		}
	}
}

void V(Semaphore *semaphore)
{
	if (semaphore->semQ == NULL)
	{
		semaphore->val++;
		return;
	}
	else
	{
		TCB_t *tcb = DelQueue(&(semaphore->semQ));
		AddQueue(&head, tcb);
	}

	semaphore->val++;
}

#endif