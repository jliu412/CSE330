//Jinhao Liu
#ifndef TCB_H
#define TCB_H

#include <ucontext.h>
#include <string.h>
#include <time.h>

typedef struct TCB_t
{
    struct TCB_t *next;
    struct TCB_t *prev;
    ucontext_t context;
    int a;
} TCB_t;

int global_thread_id = 0;

void init_TCB(TCB_t *tcb, void *function, void *stackP, int stack_size, int a, int b)
{
    memset(tcb, '\0', sizeof(TCB_t));
    getcontext(&tcb->context);
    tcb->context.uc_stack.ss_sp = stackP;
    tcb->context.uc_stack.ss_size = (size_t)stack_size;
    tcb->a = a;
    makecontext(&tcb->context, function, 1, a);
}

#endif