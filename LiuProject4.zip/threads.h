//Jinhao Liu
#ifndef THREADS_H
#define THREADS_H
#include "q.h"

void start_thread(void (*function)(int), int a, int b)
{
    void *stack = (void *)malloc(8192);
    TCB_t *tcb = NewItem();
    init_TCB(tcb, function, stack, 8192, a, b);
    AddQueue(&head, tcb);
}
void run()
{
    ucontext_t parent;
    getcontext(&parent);
    swapcontext(&parent, &(head->context));
}

void yield()
{

    if (head == NULL)
    {
        exit(0);
    }

    TCB_t *temp = head;
    RotateQ(&head);
    swapcontext(&(temp->context), &(head->context));
}

#endif