//Jinhao Liu
#include <stdio.h>
#include <unistd.h>
#include "sem.h"

Semaphore *R;
Semaphore *W;
int i, r, w, d;
int rCurr, wCurr, rWait, wWait;

void reader(int readerID)
{
    if (head != NULL)
    {
        if (wCurr > 0 || wWait > 0)
        {
            rWait++;
            P(R);
            rWait--;
        }
        rCurr++;

        printf("\n This is the %d th reader reading value i = %d for the first time \n", readerID, i);
        yield();
        printf("\n This is the %d th reader reading value i = %d for the second time \n", readerID, i);

        rCurr--;
        if (rCurr == 0)
        {
            if (wWait > 0)
                V(W);
        }
        TCB_t *tcb = DelQueue(&head);
        swapcontext(&(tcb->context), &(head->context));
    }
}

void writer(int writerID)
{
    if (head != NULL)
    {
        if (rCurr > 0 || wCurr > 0 || rWait > 0 || wWait > 0)
        {
            wWait++;
            P(W);
            wWait++;
        }
        wCurr++;

        printf("\n This is the %d th writer writing value i = %d \n", -writerID, -writerID);
        yield();
        printf("\n This is the %d th writer verifying value i = %d \n", -writerID, -writerID);

        i = -writerID;
        wCurr--;
        if (rWait > 0)
        {
            for (int j = 0; j < rWait; j++)
            {
                V(R);
            }
        }
        else if (wWait > 0)
        {
            V(W);
        }

        TCB_t *tcb = DelQueue(&head);
        swapcontext(&(tcb->context), &(head->context));
    }
}

int main()
{
    R = malloc(sizeof(Semaphore));
    W = malloc(sizeof(Semaphore));
    rCurr = wCurr = rWait = wWait = 0;
    initSem(R, 0);
    initSem(W, 0);
    InitQueue(&head);

    scanf("%d,%d", &r, &w);
    for (int j = 0; j < r + w; j++)
    {
        scanf("%d", &d);
        if (d <= 0)
        {
            start_thread(writer, d, 0);
        }
        else
        {
            start_thread(reader, d, 0);
        }
    }
    run();
    return 0;
}