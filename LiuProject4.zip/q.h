//Jinhao Liu
#ifndef Q_H
#define Q_H

#include <stdio.h>
#include <stdlib.h>
#include "tcb.h"


TCB_t *head;
TCB_t* NewItem() {
    TCB_t * item = malloc(sizeof(TCB_t));
    return item;
}

void InitQueue(TCB_t** head) {
    *head = NULL;
}
void AddQueue(TCB_t** head,TCB_t *newitem)
{
    if ((*head) == NULL)
    {
        newitem->next = newitem;
        newitem->prev = newitem;
        (*head) = newitem;
    }
    else
    {
        TCB_t* end = (*head)->prev;
        end->next = newitem;
        newitem->prev = end;
        newitem->next = *head;
        (*head)->prev = newitem;
    }
}


TCB_t *DelQueue(TCB_t** head)
{
    TCB_t *headPointer = (*head);
    if ((*head) == NULL)
    {
        return NewItem();
    }
    else if ((*head)->next == (*head))
    {
        (*head)->next = NULL;
        (*head)->prev = NULL;
        (*head) = NULL;
        return headPointer;
    }
    else
    {

        (*head)->next->prev = (*head)->prev;
        (*head)->prev->next = (*head)->next;
        (*head) = (*head)->next;
        if (headPointer != NULL)
        {
            headPointer->next = NULL;
            headPointer->prev = NULL;
        }

        return headPointer;
    }
}


void RotateQ(TCB_t** head) {

    *head = (*head)->next;
}

#endif