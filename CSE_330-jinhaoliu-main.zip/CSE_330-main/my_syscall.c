#include <linux/syscalls.h>
#include <linux/printk.h>
SYSCALL_DEFINE0(my_syscall)
{
    printk(KERN_EMERG "Hello from jinhao liu \n");
    return 0;
}
