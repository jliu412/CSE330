#ifndef PLANE_LANDING_SYSTEM_H
#define PLANE_LANDING_SYSTEM_H

#include <iostream>
using namespace std;

void requestLanding(int, int, string);
void withdrawLandingRequest(int, string);
void listLandingTimesAndFlightNumber();
void PLS();

#endif